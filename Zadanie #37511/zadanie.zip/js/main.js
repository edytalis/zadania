/* let nazwa = document.getElementById("name");
console.log(fname.value); */

let button = document.querySelector("button");


function getdatafrom() {
    let inputfname = document.getElementById("fname").value;
    let inputlname = document.getElementById("lname").value;
    let inputphone = document.getElementById("phone").value;
  console.log(inputphone);
  
  let parname = document.getElementById("par_name");
  let parlname = document.getElementById("par_lname");
  let parphone = document.getElementById("par_phone");

  inputfname = parname
}
  
button.addEventListener('click', getdatafrom);